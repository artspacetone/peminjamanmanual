import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import SignatureCanvas from 'react-signature-canvas';
import './index.css';

const API_URL = 'http://10.5.28.10:5000/api';

// --- STYLES FOR PRINTING ---
const PrintStyles = () => (
    <style>{`
        @media print {
            .no-print { display: none !important; }
            .print-only { display: block !important; }
            body { background: white; font-size: 12pt; }
            .page-break { page-break-before: always; }
        }
        .print-only { display: none; }
    `}</style>
);

// --- COMPONENT: SIDEBAR ---
const Sidebar = ({ activeTab, setActiveTab, onLogout, user }: any) => (
    <div className="w-72 bg-slate-900 text-white min-h-screen flex flex-col fixed left-0 top-0 z-50 shadow-xl no-print">
        <div className="p-6 border-b border-slate-700 bg-slate-950">
            <h1 className="text-2xl font-bold text-indigo-400 tracking-wider">WARDROBE<span className="text-white">PRO</span></h1>
            <div className="mt-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center font-bold text-lg">
                    {user.username.charAt(0).toUpperCase()}
                </div>
                <div>
                    <p className="font-bold text-sm">{user.fullname || user.username}</p>
                    <p className="text-xs text-slate-400 capitalize">{user.role}</p>
                </div>
            </div>
        </div>
        <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
            <div className="text-xs font-bold text-slate-500 uppercase px-3 mb-2 mt-2">Main Menu</div>
            {[
                { id: 'DASHBOARD', icon: 'fa-chart-pie', label: 'Dashboard' },
                { id: 'LOAN', icon: 'fa-cart-shopping', label: 'Peminjaman Baru' },
                { id: 'RETURN', icon: 'fa-rotate-left', label: 'Pengembalian' },
                { id: 'HISTORY', icon: 'fa-clock-rotate-left', label: 'Riwayat Transaksi' },
            ].map(item => (
                <button key={item.id} onClick={() => setActiveTab(item.id)}
                    className={`w-full text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${activeTab === item.id ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-900/50' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                    <i className={`fa-solid ${item.icon} w-6`}></i> {item.label}
                </button>
            ))}

            <div className="text-xs font-bold text-slate-500 uppercase px-3 mb-2 mt-6">Inventory</div>
            {[
                { id: 'ITEMS', icon: 'fa-shirt', label: 'Data Stok & Cari' },
                { id: 'SO', icon: 'fa-barcode', label: 'Stock Opname' },
            ].map(item => (
                <button key={item.id} onClick={() => setActiveTab(item.id)}
                    className={`w-full text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${activeTab === item.id ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                    <i className={`fa-solid ${item.icon} w-6`}></i> {item.label}
                </button>
            ))}

            {user.role === 'admin' && (
                <>
                    <div className="text-xs font-bold text-slate-500 uppercase px-3 mb-2 mt-6">Admin Area</div>
                    <button onClick={() => setActiveTab('USERS')} className={`w-full text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${activeTab === 'USERS' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                        <i className="fa-solid fa-users-gear w-6"></i> User Management
                    </button>
                    <button onClick={() => setActiveTab('BORROWERS')} className={`w-full text-left px-4 py-3 rounded-xl flex items-center gap-3 transition-all ${activeTab === 'BORROWERS' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}>
                        <i className="fa-solid fa-id-card w-6"></i> Data Peminjam
                    </button>
                </>
            )}
        </nav>
        <div className="p-4 border-t border-slate-800">
            <button onClick={onLogout} className="w-full bg-red-500/10 text-red-400 p-3 rounded-xl hover:bg-red-600 hover:text-white transition flex items-center justify-center gap-2">
                <i className="fa-solid fa-right-from-bracket"></i> Logout
            </button>
        </div>
    </div>
);

// --- MAIN APP ---
const App: React.FC = () => {
    const [user, setUser] = useState<any>(null);
    const [activeTab, setActiveTab] = useState('DASHBOARD');
    const [stats, setStats] = useState({ total: 0, on_loan: 0, available: 0, so_month: 0 });
    
    // States for Features
    const [cart, setCart] = useState<any[]>([]);
    const [scanInput, setScanInput] = useState('');
    const [borrowers, setBorrowers] = useState<any[]>([]);
    const [selectedBorrower, setSelectedBorrower] = useState<any>(null);
    const [loanForm, setLoanForm] = useState({ inputter_name: '', program_name: '', loan_reason: '', days: 7 });
    const sigPad = useRef<any>(null);

    // Return
    const [returnLog, setReturnLog] = useState<any[]>([]);

    // Items Search
    const [items, setItems] = useState<any[]>([]);
    const [filters, setFilters] = useState({ search: '', brand: '', color: '' });

    // SO
    const [soMode, setSoMode] = useState<'SCAN'|'UPLOAD'>('SCAN');
    const [soData, setSoData] = useState<any>({ found: [], not_found: [] });
    
    // Print
    const [printData, setPrintData] = useState<any>(null);

    // Users (Admin)
    const [usersList, setUsersList] = useState<any[]>([]);
    const [newUser, setNewUser] = useState({ username: '', password: '', fullname: '', role: 'staff' });

    useEffect(() => {
        if (user) {
            fetchStats();
            if(activeTab === 'LOAN' || activeTab === 'BORROWERS') fetchBorrowers();
            if(activeTab === 'ITEMS') fetchItems();
            if(activeTab === 'USERS' && user.role === 'admin') fetchUsers();
        }
    }, [user, activeTab]);

    // API CALLS
    const fetchStats = async () => { try { const res = await axios.get(`${API_URL}/stats`); setStats(res.data); } catch(e){} };
    const fetchBorrowers = async () => { try { const res = await axios.get(`${API_URL}/borrowers`); setBorrowers(res.data); } catch(e){} };
    const fetchItems = async () => { 
        try { 
            const q = new URLSearchParams(filters as any).toString();
            const res = await axios.get(`${API_URL}/items?${q}`); 
            setItems(res.data); 
        } catch(e){} 
    };
    const fetchUsers = async () => { try { const res = await axios.get(`${API_URL}/users`); setUsersList(res.data); } catch(e){} };

    // HANDLERS
    const handleLogin = async (e: any) => {
        e.preventDefault();
        const username = e.target.username.value;
        const password = e.target.password.value;
        try { const res = await axios.post(`${API_URL}/login`, {username, password}); setUser(res.data.user); }
        catch(err) { alert("Login Gagal"); }
    };

    const handleCreateUser = async (e: any) => {
        e.preventDefault();
        try { await axios.post(`${API_URL}/users`, newUser); fetchUsers(); setNewUser({ username: '', password: '', fullname: '', role: 'staff' }); alert("User dibuat"); }
        catch(e) { alert("Gagal"); }
    };

    const handleCreateBorrower = async (e: any) => {
        e.preventDefault();
        const data = {
            nik: e.target.nik.value,
            name: e.target.name.value,
            phone: e.target.phone.value,
            position: e.target.position.value
        };
        try { await axios.post(`${API_URL}/borrowers`, data); fetchBorrowers(); e.target.reset(); alert("Data Peminjam Tersimpan"); }
        catch(e) { alert("Gagal Simpan"); }
    };

    const handleScanLoan = async (e: any) => {
        e.preventDefault();
        if (!scanInput) return;
        if (cart.find(c => c.barcode === scanInput)) return alert("Item sudah ada");
        try {
            const res = await axios.get(`${API_URL}/items/${scanInput}`);
            if (res.data.found && res.data.data.status === 'Available') {
                setCart([...cart, res.data.data]);
                setScanInput('');
            } else { alert("Item tidak tersedia/tidak ditemukan"); }
        } catch(e) { alert("Error"); }
    };

    const handleSubmitLoan = async () => {
        if (!selectedBorrower || cart.length === 0 || sigPad.current.isEmpty()) return alert("Data Belum Lengkap");
        const signature = sigPad.current.getCanvas().toDataURL("image/png");
        const dueDate = new Date(); dueDate.setDate(dueDate.getDate() + loanForm.days);
        
        const payload = {
            borrower_id: selectedBorrower.id,
            borrower_name: selectedBorrower.name,
            inputter_name: user.fullname,
            program_name: loanForm.program_name,
            loan_reason: loanForm.loan_reason,
            due_date: dueDate,
            signature_base64: signature,
            items: cart.map(c => c.barcode)
        };

        try {
            const res = await axios.post(`${API_URL}/loan`, payload);
            alert("Berhasil!");
            // PREPARE PRINT DATA
            setPrintData({ ...payload, invoice_no: res.data.invoice_no, cart_items: cart, created_at: new Date() });
            setCart([]); setSelectedBorrower(null); sigPad.current.clear();
            setTimeout(() => window.print(), 500); // Auto print
        } catch(e: any) { alert("Gagal: " + e.message); }
    };

    const handleReturnScan = async (e: any) => {
        e.preventDefault();
        try {
            const res = await axios.post(`${API_URL}/return`, { barcode: scanInput, condition: 'Available' });
            setReturnLog([res.data.data, ...returnLog]);
            setScanInput('');
            // Optional: Print Return Receipt logic here if needed
        } catch(e: any) { alert("Gagal: " + e.response?.data?.message); }
    };

    const handleSOUpload = async (e: any) => {
        const file = e.target.files[0];
        if(!file) return;
        const fd = new FormData(); fd.append('file', file);
        try {
            const res = await axios.post(`${API_URL}/so/upload-compare`, fd);
            setSoData(res.data);
        } catch(e) { alert("Error upload"); }
    };

    if (!user) return (
        <div className="min-h-screen bg-slate-900 flex items-center justify-center">
            <div className="bg-white p-8 rounded-2xl shadow-2xl w-96">
                <h2 className="text-2xl font-bold text-center text-slate-800 mb-6">Wardrobe Login</h2>
                <form onSubmit={handleLogin} className="space-y-4">
                    <input name="username" placeholder="Username" className="w-full p-3 border rounded-lg" required />
                    <input name="password" type="password" placeholder="Password" className="w-full p-3 border rounded-lg" required />
                    <button className="w-full bg-indigo-600 text-white py-3 rounded-lg font-bold">LOGIN</button>
                </form>
            </div>
        </div>
    );

    return (
        <div className="bg-slate-50 min-h-screen font-sans">
            <PrintStyles />
            
            {/* INVOICE PRINT LAYOUT (HIDDEN ON SCREEN) */}
            {printData && (
                <div className="print-only p-8 max-w-4xl mx-auto">
                    <div className="text-center border-b pb-4 mb-4">
                        <h1 className="text-3xl font-bold">BUKTI PEMINJAMAN BARANG</h1>
                        <p>Invoice: {printData.invoice_no}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mb-6">
                        <div>
                            <p><strong>Peminjam:</strong> {printData.borrower_name}</p>
                            <p><strong>Program:</strong> {printData.program_name}</p>
                            <p><strong>Tgl Pinjam:</strong> {new Date().toLocaleDateString()}</p>
                        </div>
                        <div className="text-right">
                            <p><strong>PIC Input:</strong> {printData.inputter_name}</p>
                            <p><strong>Jatuh Tempo:</strong> {new Date(printData.due_date).toLocaleDateString()}</p>
                        </div>
                    </div>
                    <table className="w-full border-collapse border mb-6">
                        <thead>
                            <tr className="bg-gray-100">
                                <th className="border p-2">Barcode</th>
                                <th className="border p-2">Nama Barang</th>
                                <th className="border p-2">Warna/Size</th>
                            </tr>
                        </thead>
                        <tbody>
                            {printData.cart_items.map((it:any) => (
                                <tr key={it.barcode}>
                                    <td className="border p-2 font-mono">{it.barcode}</td>
                                    <td className="border p-2">{it.item_name}</td>
                                    <td className="border p-2">{it.color} / {it.size}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    <div className="flex justify-between mt-10">
                        <div className="text-center">
                            <p className="mb-16">Peminjam,</p>
                            <img src={printData.signature_base64} alt="ttd" className="h-16 mx-auto" />
                            <p className="font-bold underline">{printData.borrower_name}</p>
                        </div>
                        <div className="text-center">
                            <p className="mb-20">Petugas Wardrobe,</p>
                            <p className="font-bold underline">{printData.inputter_name}</p>
                        </div>
                    </div>
                </div>
            )}

            {/* NORMAL APP UI */}
            <div className="no-print flex">
                <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} onLogout={() => setUser(null)} user={user} />
                
                <main className="flex-1 ml-72 p-8">
                    {/* TOP HEADER */}
                    <div className="flex justify-between items-center mb-8">
                        <div>
                            <h2 className="text-2xl font-bold text-slate-800">{activeTab.replace('_', ' ')}</h2>
                            <p className="text-slate-500 text-sm">{new Date().toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                        </div>
                    </div>

                    {/* CONTENT AREA */}
                    
                    {/* 1. DASHBOARD */}
                    {activeTab === 'DASHBOARD' && (
                        <div className="grid grid-cols-4 gap-6">
                            <div className="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-indigo-500">
                                <p className="text-slate-500 text-sm font-bold uppercase">Total Aset</p>
                                <p className="text-3xl font-bold text-slate-800 mt-2">{stats.total}</p>
                            </div>
                            <div className="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-orange-500">
                                <p className="text-slate-500 text-sm font-bold uppercase">Sedang Dipinjam</p>
                                <p className="text-3xl font-bold text-orange-600 mt-2">{stats.on_loan}</p>
                            </div>
                            <div className="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-green-500">
                                <p className="text-slate-500 text-sm font-bold uppercase">Tersedia</p>
                                <p className="text-3xl font-bold text-green-600 mt-2">{stats.available}</p>
                            </div>
                        </div>
                    )}

                    {/* 2. LOAN (PEMINJAMAN) */}
                    {activeTab === 'LOAN' && (
                        <div className="flex gap-6 h-[calc(100vh-150px)]">
                            {/* FORM KIRI */}
                            <div className="w-4/12 bg-white p-6 rounded-2xl shadow-lg flex flex-col overflow-y-auto">
                                <h3 className="font-bold text-lg mb-4 text-indigo-700">1. Data Peminjam</h3>
                                
                                <div className="mb-4">
                                    <label className="block text-sm font-bold mb-1">Cari Peminjam (NIK/Nama)</label>
                                    <input list="borrowersList" className="w-full p-2 border rounded bg-slate-50" 
                                        onChange={(e) => {
                                            const val = e.target.value;
                                            const found = borrowers.find(b => b.name === val || b.nik === val);
                                            if(found) setSelectedBorrower(found);
                                        }} placeholder="Ketik NIK atau Nama..." />
                                    <datalist id="borrowersList">
                                        {borrowers.map(b => <option key={b.id} value={b.name}>{b.nik} - {b.position}</option>)}
                                    </datalist>
                                    {selectedBorrower && (
                                        <div className="mt-2 bg-indigo-50 p-3 rounded text-sm">
                                            <p className="font-bold">{selectedBorrower.name}</p>
                                            <p>{selectedBorrower.nik} | {selectedBorrower.phone}</p>
                                            <p className="text-indigo-600">{selectedBorrower.position}</p>
                                        </div>
                                    )}
                                </div>

                                <div className="space-y-3 flex-1">
                                    <input placeholder="Program / Acara" className="w-full p-2 border rounded" value={loanForm.program_name} onChange={e=>setLoanForm({...loanForm, program_name: e.target.value})} />
                                    <textarea placeholder="Keperluan Pinjam" className="w-full p-2 border rounded" value={loanForm.loan_reason} onChange={e=>setLoanForm({...loanForm, loan_reason: e.target.value})} />
                                    <div className="border rounded p-2 bg-slate-50">
                                        <p className="text-xs text-slate-500 mb-1">Tanda Tangan Peminjam:</p>
                                        <SignatureCanvas ref={sigPad} canvasProps={{ className: 'sigCanvas w-full h-24 bg-white border border-dashed' }} />
                                    </div>
                                </div>

                                <button onClick={handleSubmitLoan} className="mt-4 w-full bg-indigo-600 text-white py-3 rounded-xl font-bold hover:bg-indigo-700 transition">
                                    PROSES & CETAK INVOICE
                                </button>
                            </div>

                            {/* SCAN KANAN */}
                            <div className="w-8/12 flex flex-col gap-4">
                                <div className="bg-white p-4 rounded-2xl shadow-sm">
                                    <form onSubmit={handleScanLoan} className="flex gap-2">
                                        <input autoFocus type="text" className="flex-1 p-3 border-2 border-indigo-500 rounded-xl text-lg" placeholder="Scan Barcode Barang Disini..." value={scanInput} onChange={e=>setScanInput(e.target.value)} />
                                        <button className="bg-indigo-600 text-white px-6 rounded-xl font-bold">ADD</button>
                                    </form>
                                </div>
                                <div className="bg-white p-6 rounded-2xl shadow-sm flex-1 overflow-y-auto">
                                    <h3 className="font-bold mb-4">Keranjang Barang ({cart.length})</h3>
                                    <table className="w-full text-sm">
                                        <thead className="bg-slate-50"><tr><th className="p-3 text-left">Barcode</th><th className="p-3 text-left">Nama</th><th className="p-3 text-right">Action</th></tr></thead>
                                        <tbody>
                                            {cart.map((c, i) => (
                                                <tr key={i} className="border-b">
                                                    <td className="p-3 font-mono text-indigo-600">{c.barcode}</td>
                                                    <td className="p-3">{c.item_name}<br/><span className="text-xs text-gray-400">{c.color}</span></td>
                                                    <td className="p-3 text-right"><button onClick={()=>setCart(cart.filter(x=>x.barcode!==c.barcode))} className="text-red-500"><i className="fa-solid fa-trash"></i></button></td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* 3. RETURN (PENGEMBALIAN) */}
                    {activeTab === 'RETURN' && (
                        <div className="flex gap-6 h-[calc(100vh-150px)]">
                            <div className="w-1/3 bg-white p-8 rounded-2xl shadow-lg text-center h-fit">
                                <h2 className="text-xl font-bold mb-6 text-green-700">Scan Pengembalian</h2>
                                <form onSubmit={handleReturnScan}>
                                    <input autoFocus type="text" className="w-full p-4 border-2 border-green-500 rounded-xl text-center text-xl font-mono mb-4" 
                                        placeholder="Scan Barcode..." value={scanInput} onChange={e=>setScanInput(e.target.value)} />
                                </form>
                                <p className="text-sm text-gray-400">Scan barcode, status akan otomatis menjadi 'Returned'.</p>
                            </div>
                            <div className="w-2/3 bg-white p-6 rounded-2xl shadow-sm flex-1 overflow-y-auto">
                                <h3 className="font-bold mb-4">Log Pengembalian Sesi Ini</h3>
                                <div className="space-y-2">
                                    {returnLog.map((log, i) => (
                                        <div key={i} className="p-4 bg-green-50 border border-green-200 rounded-xl flex justify-between items-center animate-pulse-once">
                                            <div>
                                                <p className="font-bold text-green-800">{log.item_name}</p>
                                                <p className="text-xs text-green-600">Peminjam: {log.borrower_name}</p>
                                            </div>
                                            <div className="text-right">
                                                <p className="font-mono font-bold">{new Date().toLocaleTimeString()}</p>
                                                <span className="bg-green-200 text-green-800 text-xs px-2 py-1 rounded">DITERIMA</span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    )}

                    {/* 4. STOCK OPNAME (SCAN & UPLOAD) */}
                    {activeTab === 'SO' && (
                        <div className="bg-white rounded-2xl shadow-sm p-6 min-h-[500px]">
                            <div className="flex gap-4 border-b pb-4 mb-6">
                                <button onClick={()=>setSoMode('SCAN')} className={`px-4 py-2 rounded-lg font-bold ${soMode==='SCAN'?'bg-purple-600 text-white':'bg-gray-100'}`}>Manual Scan</button>
                                <button onClick={()=>setSoMode('UPLOAD')} className={`px-4 py-2 rounded-lg font-bold ${soMode==='UPLOAD'?'bg-purple-600 text-white':'bg-gray-100'}`}>Upload Excel Compare</button>
                            </div>

                            {soMode === 'UPLOAD' ? (
                                <div className="text-center py-10">
                                    <h3 className="text-xl font-bold mb-4">Upload Hasil Scan Barcode (Excel)</h3>
                                    <p className="text-gray-500 mb-6">Sistem akan mencocokkan barcode di Excel dengan Database.</p>
                                    <input type="file" onChange={handleSOUpload} className="mb-4" />
                                    
                                    <div className="grid grid-cols-2 gap-6 mt-8 text-left">
                                        <div className="bg-green-50 p-4 rounded-xl">
                                            <h4 className="font-bold text-green-700">Sesuai / Ditemukan ({soData.found.length})</h4>
                                            <div className="h-64 overflow-y-auto mt-2 text-xs">
                                                {soData.found.map((f:any, i:number) => <div key={i} className="border-b py-1">{f.barcode} - {f.item_name}</div>)}
                                            </div>
                                        </div>
                                        <div className="bg-red-50 p-4 rounded-xl">
                                            <h4 className="font-bold text-red-700">Tidak Sesuai / Tidak Ada di DB ({soData.not_found.length})</h4>
                                            <div className="h-64 overflow-y-auto mt-2 text-xs font-mono text-red-600">
                                                {soData.not_found.map((f:any, i:number) => <div key={i} className="border-b py-1">{f}</div>)}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ) : (
                                <div>Fitur Manual Scan SO (Sama seperti sebelumnya)</div>
                            )}
                        </div>
                    )}

                    {/* 5. DATA STOCK (ADVANCED SEARCH) */}
                    {activeTab === 'ITEMS' && (
                        <div className="bg-white rounded-2xl shadow-sm p-6">
                            <div className="grid grid-cols-4 gap-4 mb-6 bg-slate-50 p-4 rounded-xl">
                                <input placeholder="Cari Nama / Barcode..." className="p-2 border rounded" value={filters.search} onChange={e=>setFilters({...filters, search: e.target.value})} />
                                <input placeholder="Filter Brand..." className="p-2 border rounded" value={filters.brand} onChange={e=>setFilters({...filters, brand: e.target.value})} />
                                <input placeholder="Filter Warna..." className="p-2 border rounded" value={filters.color} onChange={e=>setFilters({...filters, color: e.target.value})} />
                                <button onClick={fetchItems} className="bg-indigo-600 text-white rounded font-bold">CARI DATA</button>
                            </div>
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead className="bg-slate-100 text-slate-600">
                                        <tr>
                                            <th className="p-3 text-left">Barcode</th>
                                            <th className="p-3 text-left">Item Name</th>
                                            <th className="p-3 text-left">Brand</th>
                                            <th className="p-3 text-left">Color/Size</th>
                                            <th className="p-3 text-left">Price</th>
                                            <th className="p-3 text-left">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {items.map((item, i) => (
                                            <tr key={i} className="border-b hover:bg-slate-50">
                                                <td className="p-3 font-mono text-indigo-600 font-bold">{item.barcode}</td>
                                                <td className="p-3 font-medium">{item.item_name}</td>
                                                <td className="p-3">{item.brand}</td>
                                                <td className="p-3">{item.color} - {item.size}</td>
                                                <td className="p-3">{new Intl.NumberFormat('id-ID').format(item.price)}</td>
                                                <td className="p-3"><span className={`px-2 py-1 rounded text-xs ${item.status==='Available'?'bg-green-100 text-green-600':'bg-orange-100 text-orange-600'}`}>{item.status}</span></td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}

                    {/* 6. ADMIN: USER MANAGEMENT */}
                    {activeTab === 'USERS' && user.role === 'admin' && (
                        <div className="flex gap-6">
                            <div className="w-1/3 bg-white p-6 rounded-2xl shadow-sm h-fit">
                                <h3 className="font-bold mb-4">Buat User Baru</h3>
                                <form onSubmit={handleCreateUser} className="space-y-3">
                                    <input placeholder="Username" className="w-full p-2 border rounded" value={newUser.username} onChange={e=>setNewUser({...newUser, username: e.target.value})} required />
                                    <input placeholder="Password" type="password" className="w-full p-2 border rounded" value={newUser.password} onChange={e=>setNewUser({...newUser, password: e.target.value})} required />
                                    <input placeholder="Nama Lengkap" className="w-full p-2 border rounded" value={newUser.fullname} onChange={e=>setNewUser({...newUser, fullname: e.target.value})} required />
                                    <select className="w-full p-2 border rounded" value={newUser.role} onChange={e=>setNewUser({...newUser, role: e.target.value})}>
                                        <option value="staff">Staff</option>
                                        <option value="admin">Admin</option>
                                    </select>
                                    <button className="w-full bg-indigo-600 text-white py-2 rounded font-bold">SIMPAN USER</button>
                                </form>
                            </div>
                            <div className="w-2/3 bg-white p-6 rounded-2xl shadow-sm">
                                <h3 className="font-bold mb-4">Daftar User</h3>
                                <table className="w-full text-sm">
                                    <thead><tr className="bg-slate-100"><th className="p-2 text-left">Username</th><th className="p-2 text-left">Nama</th><th className="p-2 text-left">Role</th></tr></thead>
                                    <tbody>
                                        {usersList.map(u => (
                                            <tr key={u.id} className="border-b">
                                                <td className="p-2 font-bold">{u.username}</td>
                                                <td className="p-2">{u.fullname}</td>
                                                <td className="p-2"><span className="bg-gray-100 px-2 rounded text-xs">{u.role}</span></td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}

                    {/* 7. ADMIN: BORROWERS MASTER */}
                    {activeTab === 'BORROWERS' && (
                        <div className="flex gap-6">
                            <div className="w-1/3 bg-white p-6 rounded-2xl shadow-sm h-fit">
                                <h3 className="font-bold mb-4">Input Data Peminjam</h3>
                                <form onSubmit={handleCreateBorrower} className="space-y-3">
                                    <input name="nik" placeholder="NIK" className="w-full p-2 border rounded" required />
                                    <input name="name" placeholder="Nama Lengkap" className="w-full p-2 border rounded" required />
                                    <input name="phone" placeholder="No HP/WA" className="w-full p-2 border rounded" required />
                                    <input name="position" placeholder="Jabatan / Divisi" className="w-full p-2 border rounded" required />
                                    <button className="w-full bg-indigo-600 text-white py-2 rounded font-bold">SIMPAN DATA</button>
                                </form>
                            </div>
                            <div className="w-2/3 bg-white p-6 rounded-2xl shadow-sm">
                                <h3 className="font-bold mb-4">Master Data Peminjam</h3>
                                <table className="w-full text-sm">
                                    <thead><tr className="bg-slate-100"><th className="p-2 text-left">NIK</th><th className="p-2 text-left">Nama</th><th className="p-2 text-left">Jabatan</th></tr></thead>
                                    <tbody>
                                        {borrowers.map(b => (
                                            <tr key={b.id} className="border-b">
                                                <td className="p-2 font-mono text-indigo-600">{b.nik}</td>
                                                <td className="p-2 font-bold">{b.name}</td>
                                                <td className="p-2">{b.position}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}

                </main>
            </div>
        </div>
    );
};

export default App;