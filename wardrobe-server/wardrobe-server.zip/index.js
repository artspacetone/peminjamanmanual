/*** FILE: index.js (BACKEND FIXED & LOGGING) ***/
const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const multer = require('multer');
const xlsx = require('xlsx');
const fs = require('fs');

const app = express();
const PORT = 5000;
const HOST = '0.0.0.0'; 

app.use(cors());
app.use(express.json({ limit: '50mb' }));

// KONFIGURASI DATABASE
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'wardrobe_db',
  password: 'Bohong19', 
  port: 5432,
});

const upload = multer({ dest: 'uploads/' });

// --- HELPER: LOGGER ---
async function logActivity(client, user, action, entity, id, details) {
    try {
        const query = `INSERT INTO activity_logs (user_name, action_type, entity, entity_id, details) VALUES ($1, $2, $3, $4, $5)`;
        const params = [user || 'System', action, entity, id, details];
        if (client) {
            await client.query(query, params);
        } else {
            await pool.query(query, params);
        }
    } catch (err) {
        console.error("Gagal mencatat log:", err);
    }
}

// --- HELPER: CLEANING ---
function cleanPrice(input) {
    if (!input) return 0;
    if (typeof input === 'number') return input;
    let cleanString = String(input).replace(/[^0-9.]/g, ''); 
    let result = parseFloat(cleanString);
    return isNaN(result) ? 0 : result;
}

function parseExcelDate(rawDate) {
    if (!rawDate) return null;
    let dateObj = null;
    if (rawDate instanceof Date) dateObj = rawDate;
    else if (typeof rawDate === 'number') dateObj = new Date(Math.round((rawDate - 25569) * 86400 * 1000));
    else if (typeof rawDate === 'string') {
        const cleanDate = rawDate.trim();
        if (cleanDate.match(/^\d{1,2}\/\d{1,2}\/\d{4}$/)) {
            const parts = cleanDate.split('/');
            dateObj = new Date(parts[2], parts[1] - 1, parts[0]);
        } else {
            dateObj = new Date(cleanDate);
        }
    }
    return (dateObj && !isNaN(dateObj.getTime())) ? dateObj : null;
}

// --- API ROUTES ---

// 1. LOGIN
app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const result = await pool.query("SELECT * FROM users WHERE username = $1 AND password = $2", [username, password]);
        if (result.rows.length > 0) {
            res.json({ success: true, user: result.rows[0] });
        } else {
            res.status(401).json({ success: false, message: "Username/Password Salah!" });
        }
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// 2. USERS MANAGEMENT (FIXED 404)
app.get('/api/users', async (req, res) => {
    try {
        const result = await pool.query("SELECT id, username, role, fullname FROM users ORDER BY id ASC");
        res.json(result.rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/users', async (req, res) => {
    try {
        const { username, password, role, fullname, current_user } = req.body;
        await pool.query("INSERT INTO users (username, password, role, fullname) VALUES ($1, $2, $3, $4)", 
            [username, password, role, fullname]);
        
        await logActivity(null, current_user, 'CREATE', 'USER', username, `Membuat user baru: ${fullname} (${role})`);
        res.json({ success: true, message: "User berhasil dibuat" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/api/users/:id', async (req, res) => {
    try {
        // Ambil user dari query param atau body jika perlu logging who deleted it, disini simpel saja
        const id = req.params.id;
        await pool.query("DELETE FROM users WHERE id=$1", [id]);
        res.json({ success: true, message: "User dihapus" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// 3. BORROWERS / PEMINJAM (FIXED 404)
app.get('/api/borrowers', async (req, res) => {
    try {
        const { q } = req.query;
        let query = "SELECT * FROM borrowers";
        let params = [];
        if (q) {
            query += " WHERE name ILIKE $1 OR nik ILIKE $1";
            params.push(`%${q}%`);
        }
        query += " ORDER BY name ASC LIMIT 50";
        const result = await pool.query(query, params);
        res.json(result.rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.post('/api/borrowers', async (req, res) => {
    try {
        const { nik, name, phone, position, current_user } = req.body;
        await pool.query(`
            INSERT INTO borrowers (nik, name, phone, position) 
            VALUES ($1, $2, $3, $4) 
            ON CONFLICT (nik) DO UPDATE SET name=EXCLUDED.name, phone=EXCLUDED.phone, position=EXCLUDED.position`, 
            [nik, name, phone, position]);
        
        await logActivity(null, current_user, 'UPSERT', 'BORROWER', nik, `Input/Update Peminjam: ${name}`);
        res.json({ success: true, message: "Data Peminjam Disimpan" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// 4. ITEMS & STOCK
app.get('/api/items', async (req, res) => {
    try {
        const { search, brand, color } = req.query;
        let query = "SELECT * FROM items WHERE 1=1";
        let params = [];
        let count = 1;

        if (search) {
            query += ` AND (item_name ILIKE $${count} OR barcode ILIKE $${count})`;
            params.push(`%${search}%`);
            count++;
        }
        if (brand) {
            query += ` AND brand ILIKE $${count}`;
            params.push(`%${brand}%`);
            count++;
        }
        if (color) {
            query += ` AND color ILIKE $${count}`;
            params.push(`%${color}%`);
            count++;
        }

        query += " ORDER BY created_at DESC LIMIT 100";
        const result = await pool.query(query, params);
        res.json(result.rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/items/:barcode', async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM items WHERE barcode = $1', [req.params.barcode]);
        if (result.rows.length > 0) res.json({ found: true, data: result.rows[0] });
        else res.json({ found: false });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// 5. UPLOAD EXCEL (ADD DATA & LOGGING)
app.post('/api/upload-excel', upload.single('file'), async (req, res) => {
    if (!req.file) return res.status(400).json({ success: false, message: "File required" });
    
    // Ambil username dari body (karena pakai multer, field harus dikirim sbg form-data)
    const currentUser = req.body.user || 'System';

    try {
        const filePath = req.file.path;
        const workbook = xlsx.readFile(filePath, { cellDates: true });
        const data = xlsx.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]]);
        const client = await pool.connect();
        
        let newCount = 0;
        let updateCount = 0;

        try {
            await client.query('BEGIN');
            for (const row of data) {
                const barcode = String(row['Barcode'] || row['barcode'] || '').trim();
                if (!barcode) continue;

                // Cek data lama untuk log
                const oldDataRes = await client.query("SELECT * FROM items WHERE barcode = $1", [barcode]);
                const isNew = oldDataRes.rows.length === 0;

                const name = row['Name'] || row['name'] || row['Item Name'];
                const sex = row['Sex'] || row['sex'];
                const color = row['Color'] || row['color'];
                const size = row['Size'] || row['size'];
                const brand = row['Brand'] || row['brand'];
                const price = cleanPrice(row['Price'] || row['price'] || row['Harga']);
                const receiveNo = row['Receive No'] || row['receive_no'];
                const receiveDate = parseExcelDate(row['Receive Date'] || row['receive_date']);

                const query = `
                  INSERT INTO items (barcode, item_name, sex, color, size, brand, price, receive_no, receive_date, status)
                  VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'Available')
                  ON CONFLICT (barcode) DO UPDATE SET 
                    item_name = EXCLUDED.item_name, sex = EXCLUDED.sex, color = EXCLUDED.color,
                    size = EXCLUDED.size, brand = EXCLUDED.brand, price = EXCLUDED.price,
                    updated_at = CURRENT_TIMESTAMP;
                `;
                await client.query(query, [barcode, name, sex, color, size, brand, price, receiveNo, receiveDate]);

                if (isNew) newCount++; else updateCount++;
            }

            // Catat Log Bulk
            await logActivity(client, currentUser, 'UPLOAD', 'ITEMS', 'BULK', `Upload Excel: ${newCount} Baru, ${updateCount} Update.`);
            
            await client.query('COMMIT');
            fs.unlinkSync(filePath);
            res.json({ success: true, message: `Upload Sukses! ${newCount} Data Baru, ${updateCount} Data Diupdate.` });
        } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
    } catch (err) { res.status(500).json({ success: false, message: err.message }); }
});

// 6. TRANSAKSI LOAN (LOGGING)
app.post('/api/loan', async (req, res) => {
    const client = await pool.connect();
    try {
        const { borrower_id, borrower_name, inputter_name, program_name, loan_reason, items, signature_base64, due_date } = req.body;
        await client.query('BEGIN');
        
        const dateStr = new Date().toISOString().slice(0,10).replace(/-/g, '');
        const countRes = await client.query("SELECT count(*) as count FROM loan_transactions");
        const invoice_no = `LOAN-${dateStr}-${String(parseInt(countRes.rows[0].count) + 1).padStart(3, '0')}`;

        const headerRes = await client.query(`
            INSERT INTO loan_transactions (invoice_no, borrower_id, borrower_name, inputter_name, program_name, loan_reason, due_date, signature_base64)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id
        `, [invoice_no, borrower_id, borrower_name, inputter_name, program_name, loan_reason, due_date, signature_base64]);

        const txId = headerRes.rows[0].id;

        for (const code of items) {
            const check = await client.query("SELECT status FROM items WHERE barcode=$1", [code]);
            if(check.rows.length === 0 || check.rows[0].status !== 'Available') throw new Error(`Item ${code} tidak tersedia.`);
            await client.query(`INSERT INTO loan_items (transaction_id, barcode, status) VALUES ($1, $2, 'On Loan')`, [txId, code]);
            await client.query(`UPDATE items SET status = 'On Loan', updated_at = NOW() WHERE barcode=$1`, [code]);
        }

        await logActivity(client, inputter_name, 'LOAN', 'TRANSACTION', invoice_no, `Peminjaman ${items.length} item oleh ${borrower_name}`);

        await client.query('COMMIT');
        res.json({ success: true, invoice_no, message: "Peminjaman Berhasil!", transaction_id: txId });
    } catch (err) { await client.query('ROLLBACK'); res.status(400).json({ success: false, message: err.message }); } finally { client.release(); }
});

// 7. RETURN (LOGGING)
app.post('/api/return', async (req, res) => {
    const client = await pool.connect();
    try {
        const { barcode, condition, user } = req.body;
        await client.query('BEGIN');
        const loanRes = await client.query(`
            SELECT li.id, li.transaction_id, lt.borrower_name 
            FROM loan_items li JOIN loan_transactions lt ON li.transaction_id = lt.id
            WHERE li.barcode=$1 AND li.status='On Loan' 
            ORDER BY li.id DESC LIMIT 1
        `, [barcode]);

        if(loanRes.rows.length === 0) throw new Error("Item tidak sedang dipinjam.");
        
        const itemData = loanRes.rows[0];
        await client.query("UPDATE loan_items SET status='Returned', returned_at=NOW() WHERE id=$1", [itemData.id]);
        await client.query("UPDATE items SET status=$1, updated_at=NOW() WHERE barcode=$2", [condition, barcode]);
        
        await logActivity(client, user, 'RETURN', 'ITEM', barcode, `Pengembalian item dari ${itemData.borrower_name}, Kondisi: ${condition}`);
        
        await client.query('COMMIT');
        res.json({ success: true, message: `Return Sukses`, data: itemData });
    } catch (err) { await client.query('ROLLBACK'); res.status(400).json({ success: false, message: err.message }); } finally { client.release(); }
});

// 8. SO UPLOAD COMPARE ONLY (NO MANUAL SCAN)
app.post('/api/so/upload-compare', upload.single('file'), async (req, res) => {
    if (!req.file) return res.status(400).json({ success: false });
    const currentUser = req.body.user || 'System';
    try {
        const filePath = req.file.path;
        const workbook = xlsx.readFile(filePath);
        const data = xlsx.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]]);
        
        const uploadedBarcodes = data.map(r => String(r['Barcode'] || r['barcode'] || '').trim()).filter(b => b);
        
        const client = await pool.connect();
        const foundItems = [];
        const notFoundBarcodes = [];
        
        try {
            await client.query('BEGIN');
            for(const code of uploadedBarcodes) {
                const resDb = await client.query("SELECT * FROM items WHERE barcode = $1", [code]);
                if(resDb.rows.length > 0) {
                    foundItems.push(resDb.rows[0]);
                    await client.query("UPDATE items SET last_so_date = NOW(), so_by = $1 WHERE barcode = $2", ['Bulk Upload', code]);
                } else {
                    notFoundBarcodes.push(code);
                }
            }
            await logActivity(client, currentUser, 'SO', 'STOCK_OPNAME', 'BATCH', `SO Excel: ${foundItems.length} Sesuai, ${notFoundBarcodes.length} Tidak Ditemukan`);
            await client.query('COMMIT');
        } catch(e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
        
        fs.unlinkSync(filePath);
        res.json({ success: true, found: foundItems, not_found: notFoundBarcodes });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// 9. ACTIVITY LOGS REPORT
app.get('/api/logs', async (req, res) => {
    try {
        const result = await pool.query("SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT 100");
        res.json(result.rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/stats', async (req, res) => {
    try {
        const total = await pool.query("SELECT count(*) FROM items");
        const onLoan = await pool.query("SELECT count(*) FROM items WHERE status = 'On Loan'");
        const available = await pool.query("SELECT count(*) FROM items WHERE status = 'Available'");
        const startOfMonth = new Date(); startOfMonth.setDate(1);
        const soCount = await pool.query("SELECT count(*) FROM items WHERE last_so_date >= $1", [startOfMonth]);
        res.json({
            total: parseInt(total.rows[0].count), on_loan: parseInt(onLoan.rows[0].count),
            available: parseInt(available.rows[0].count), so_month: parseInt(soCount.rows[0].count)
        });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/api/history', async (req, res) => {
    try {
        const result = await pool.query(`
            SELECT lt.invoice_no, lt.borrower_name, lt.loan_date, li.barcode, i.item_name, li.status, li.returned_at
            FROM loan_transactions lt JOIN loan_items li ON lt.id = li.transaction_id JOIN items i ON li.barcode = i.barcode
            ORDER BY li.returned_at DESC NULLS LAST, lt.created_at DESC LIMIT 50
        `);
        res.json(result.rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.listen(PORT, HOST, () => console.log(`Server running at http://${HOST}:${PORT}`));